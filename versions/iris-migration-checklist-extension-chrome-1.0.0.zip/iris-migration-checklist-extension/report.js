/**
 * Report renderer — reads the sectioned comparison report from storage
 * and renders collapsible, entity-aware diff sections.
 */

import { loadReport } from './storage.js';

document.addEventListener('DOMContentLoaded', async () => {
    const container = document.getElementById('report');

    try {
        const report = await loadReport();

        if (!report) {
            container.innerHTML = '<p class="error">No comparison data found. Run a comparison from the extension popup first.</p>';
            return;
        }

        renderReport(container, report);
    } catch (err) {
        container.innerHTML = `<p class="error">Failed to load report: ${escapeHtml(err.message)}</p>`;
    }
});

/* ------------------------------------------------------------------ */
/*  Top-level report                                                   */
/* ------------------------------------------------------------------ */

function renderReport(container, report) {
    // ---- Header ----
    const header = document.createElement('header');
    header.innerHTML = `
    <h1>Migration Comparison Report</h1>
    <dl class="meta">
      <dt>Saved Server</dt>  <dd>${escapeHtml(report.savedServer)}</dd>
      <dt>Current Server</dt> <dd>${escapeHtml(report.currentServer)}</dd>
      <dt>Saved At</dt>       <dd>${formatTimestamp(report.savedTimestamp)}</dd>
      <dt>Compared At</dt>    <dd>${formatTimestamp(report.timestamp)}</dd>
    </dl>
  `;
    container.appendChild(header);

    // ---- Zero-diff shortcut ----
    if (report.totalDifferences === 0) {
        const msg = document.createElement('p');
        msg.className = 'success banner';
        msg.textContent = 'No differences found — servers are in sync.';
        container.appendChild(msg);
        return;
    }

    // ---- Global summary ----
    const summaryEl = document.createElement('section');
    summaryEl.className = 'global-summary';
    summaryEl.innerHTML = `
    <h2>${report.totalDifferences} difference${report.totalDifferences !== 1 ? 's' : ''} found</h2>
  `;
    container.appendChild(summaryEl);

    // ---- Render each section ----
    for (const section of report.sections) {
        const sectionEl = renderSection(section);
        container.appendChild(sectionEl);
    }
}

/* ------------------------------------------------------------------ */
/*  Section rendering                                                  */
/* ------------------------------------------------------------------ */

function renderSection(section) {
    const wrapper = document.createElement('section');
    wrapper.className = 'entity-section';

    // Collapsible header
    const details = document.createElement('details');
    details.open = section.totalDifferences > 0;

    const summary = document.createElement('summary');
    summary.innerHTML = buildSectionHeader(section);
    details.appendChild(summary);

    const body = document.createElement('div');
    body.className = 'section-body';

    if (section.totalDifferences === 0) {
        const msg = document.createElement('p');
        msg.className = 'in-sync-msg';
        msg.textContent = 'All items are in sync.';
        body.appendChild(msg);
    } else if (section.strategy === 'entity') {
        renderEntityBody(body, section);
    } else {
        renderFlatBody(body, section);
    }

    details.appendChild(body);
    wrapper.appendChild(details);
    return wrapper;
}

function buildSectionHeader(section) {
    const diffBadge = section.totalDifferences > 0
        ? `<span class="section-badge diff">${section.totalDifferences}</span>`
        : '<span class="section-badge sync">✓</span>';

    return `<span class="section-label">${escapeHtml(section.label)}</span> ${diffBadge}`;
}

/* ------------------------------------------------------------------ */
/*  Entity strategy body                                               */
/* ------------------------------------------------------------------ */

function renderEntityBody(body, section) {
    // Missing entities
    if (section.missing.length > 0) {
        body.appendChild(renderEntityList(
            'Missing in Current Server',
            'missing',
            section.missing.map(m => m.entity),
            true
        ));
    }

    // Extra entities
    if (section.extra.length > 0) {
        body.appendChild(renderEntityList(
            'Extra in Current Server',
            'extra',
            section.extra.map(e => e.entity),
            true
        ));
    }

    // Matched entities with property diffs
    const changed = section.matched.filter(m => m.differences.length > 0);
    if (changed.length > 0) {
        const changedSection = document.createElement('div');
        changedSection.className = 'diff-group changed';

        const h4 = document.createElement('h4');
        h4.textContent = 'Changed Properties';
        changedSection.appendChild(h4);

        for (const entity of changed) {
            changedSection.appendChild(renderPropertyDiffTable(entity));
        }

        body.appendChild(changedSection);
    }

    // In-sync count
    const inSync = section.matched.filter(m => m.differences.length === 0);
    if (inSync.length > 0) {
        const syncEl = document.createElement('p');
        syncEl.className = 'in-sync-msg';
        syncEl.textContent = `${inSync.length} item${inSync.length !== 1 ? 's' : ''} in sync: ${inSync.map(m => m.id).join(', ')}`;
        body.appendChild(syncEl);
    }

    // Child sections (e.g. namespace children)
    if (section.childSections && section.childSections.length > 0) {
        const childWrapper = document.createElement('div');
        childWrapper.className = 'child-sections';

        // Group child sections by parentId
        const grouped = groupBy(section.childSections, 'parentId');

        for (const [parentId, childSections] of grouped) {
            const parentBlock = document.createElement('div');
            parentBlock.className = 'child-parent-block';

            const parentHeader = document.createElement('h4');
            parentHeader.className = 'child-parent-header';
            parentHeader.textContent = `Namespace: ${parentId}`;
            parentBlock.appendChild(parentHeader);

            for (const child of childSections) {
                parentBlock.appendChild(renderSection(child));
            }

            childWrapper.appendChild(parentBlock);
        }

        body.appendChild(childWrapper);
    }
}

/* ------------------------------------------------------------------ */
/*  Flat strategy body                                                 */
/* ------------------------------------------------------------------ */

function renderFlatBody(body, section) {
    if (section.missing.length > 0) {
        body.appendChild(renderEntityList(
            'Missing in Current Server',
            'missing',
            section.missing
        ));
    }

    if (section.extra.length > 0) {
        body.appendChild(renderEntityList(
            'Extra in Current Server',
            'extra',
            section.extra
        ));
    }
}

/* ------------------------------------------------------------------ */
/*  Reusable rendering components                                      */
/* ------------------------------------------------------------------ */

/**
 * Render a list of entity objects as a styled block.
 * If idOnly is true, only shows the entity ID (no property details).
 */
function renderEntityList(title, type, entities, idOnly = false) {
    const block = document.createElement('div');
    block.className = `diff-group ${type}`;

    const h4 = document.createElement('h4');
    h4.textContent = `${title} (${entities.length})`;
    block.appendChild(h4);

    const list = document.createElement('div');
    list.className = 'entity-card-list';

    for (const entity of entities) {
        const card = document.createElement('div');
        card.className = `entity-card ${type}`;

        const id = entity.id || entity.name || '';
        if (id) {
            const idEl = document.createElement('div');
            idEl.className = 'entity-card-id';
            idEl.textContent = id;
            card.appendChild(idEl);
        }

        if (!idOnly) {
            const propsEl = document.createElement('dl');
            propsEl.className = 'entity-card-props';

            for (const [key, value] of Object.entries(entity)) {
                if (key === 'id') continue;
                const dt = document.createElement('dt');
                dt.textContent = key;
                const dd = document.createElement('dd');
                dd.textContent = formatPropValue(value);
                propsEl.appendChild(dt);
                propsEl.appendChild(dd);
            }

            card.appendChild(propsEl);
        }
        list.appendChild(card);
    }

    block.appendChild(list);
    return block;
}

/**
 * Render a per-entity property diff table.
 */
function renderPropertyDiffTable(entity) {
    const wrapper = document.createElement('div');
    wrapper.className = 'prop-diff-block';

    const header = document.createElement('div');
    header.className = 'prop-diff-header';
    header.textContent = entity.id;
    wrapper.appendChild(header);

    const table = document.createElement('table');
    table.className = 'prop-diff-table';
    table.innerHTML = `
    <thead>
      <tr>
        <th>Property</th>
        <th>Saved Value</th>
        <th>Current Value</th>
      </tr>
    </thead>
  `;

    const tbody = document.createElement('tbody');

    for (const diff of entity.differences) {
        const tr = document.createElement('tr');
        tr.innerHTML = `
      <td class="prop-name">${escapeHtml(diff.property)}</td>
      <td class="prop-value saved">${formatValueCell(diff.saved)}</td>
      <td class="prop-value current">${formatValueCell(diff.current)}</td>
    `;
        tbody.appendChild(tr);
    }

    table.appendChild(tbody);
    wrapper.appendChild(table);
    return wrapper;
}

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

function formatValueCell(value) {
    if (value === undefined) return '<span class="empty">—</span>';
    if (value === null) return '<span class="null">null</span>';
    if (typeof value === 'object') {
        return `<pre>${escapeHtml(JSON.stringify(value, null, 2))}</pre>`;
    }
    return escapeHtml(String(value));
}

function formatPropValue(value) {
    if (value === undefined || value === null) return '—';
    if (typeof value === 'object') return JSON.stringify(value);
    return String(value);
}

function formatTimestamp(iso) {
    if (!iso) return '—';
    try {
        return new Date(iso).toLocaleString();
    } catch {
        return escapeHtml(iso);
    }
}

function escapeHtml(str) {
    if (str == null) return '';
    const el = document.createElement('span');
    el.textContent = String(str);
    return el.innerHTML;
}

function groupBy(arr, key) {
    const map = new Map();
    for (const item of arr) {
        const k = item[key];
        if (!map.has(k)) map.set(k, []);
        map.get(k).push(item);
    }
    return map;
}
